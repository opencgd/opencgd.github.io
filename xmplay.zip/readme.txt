XM-Player Applet - Jagex Software (http://www.jagex.com)
Written by Andrew Gower - Copyright 2000
Plays fast-tracker 2 module files without any plugins!!

Terms And Conditions
--------------------

You can freely copy and use this applet provided you abide by the
following terms:
1) None of the files are modified, or seperated.
2) When copying this applet this documentation must remain with it.
3) If the applet is placed on a webpage the message it displays must be
   clearly visible for all visitors to see.
4) Reverse engineering, decompiling, or using any part of this applet in
   any other applet/application is stictly prohibited.

Using the applet
----------------

Using this applet on your webpage is very simple. First you need a fasttracker 2
module which you want to play. (file extension .xm). Copy this module onto your
webserver. Then copy xmplay.class, and the 'jagex' folder onto the webserver
(It's easiest if you copy them into the same directory as the .xm file)

Then all you have to do is add the following lines of text into your html file:

<applet code="xmplay.class" width=250 height=40>
<param name="xm" value="mod.xm">
<param name="len" value="500000">
</applet>

Finally you need to change a few details to match the mod you have selected.
1) Change the text 'mod.xm' to the name of the module file you want to play
2) Change the number 500000 to the size of your xm file (in bytes)

And thats it! - Have fun

If you have any comments/bug reports please email me at:
andrew@jagex.com
